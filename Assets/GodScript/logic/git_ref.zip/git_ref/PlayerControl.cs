﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using com.jdxk;
using com.jdxk.Configs;
using com.jdxk.net.message;

public class PlayerControl : BroadCastControl
{
    #region 玩家数据
    public int gold { get; set; }		    // 金币
    public int bankMoney { get; set; }		// 元宝
    public int exp { get; set; }			        // 经验值
    public int bagNum { get; set; }		        // 背包数量	
    public int storeNum { get; set; }		        // 仓库数量	
    public Msg_PlayerSkillInfo skillInfoList { get; set; }			//玩家技能列表:主动技能以及被动技能
    public int bindBankMoney { get; set; }		// 绑定元宝
    public int skillPoint { get; set; }		// 技能点
    public int story { get; set; }		// 阅历值
    public int rage { get; set; }		// 怒气值
    public int equipEssence { get; set; }   //装备精华
    public int arenaMoney { get;set;} //战魂
	public int achievementPoint { get; set; }   //成就点
	public int xunXianBagNum { get; set; }		// 寻仙背包数量	
	public int xianYuan { get; set; }		// 仙缘数量	
	public int expOffline { get; set; }		// 离线经验
    public int prestige { get; set; }   //阵营威望
	

    public override void SetPlayerBaseInfo(Msg_PlayerBaseInfo baseInfo)
    {
        base.SetPlayerBaseInfo(baseInfo);
        exp = baseInfo.Exp;
        bagNum = baseInfo.BagNum;
        storeNum = baseInfo.StoreNum;
        skillInfoList = baseInfo.SkillInfoList;
        gold = baseInfo.Gold;
        bankMoney = baseInfo.BankMoney;
        bindBankMoney = baseInfo.BindBankMoney;
        skillPoint = baseInfo.Skillpoint;
        story = baseInfo.Story;
        rage = baseInfo.Rage;
        equipEssence = baseInfo.EquipEssence;
        arenaMoney = baseInfo.ArenaMoney;
		xianYuan = baseInfo.Xianyuan;
		achievementPoint = 0;
		xunXianBagNum = XunXianCellManager.MaxCellNum;	// 寻仙背包格子默认全开放
		expOffline = baseInfo.OfflineExp;
        prestige = baseInfo.Prestige;
    }

    //获取玩家身上的元宝，默认包括身上的绑定元宝
    public int GetPlayerGold(bool bIncludeBind = true)
    {
        return bIncludeBind ? bankMoney + bindBankMoney : bankMoney;
    }

    #endregion
}
