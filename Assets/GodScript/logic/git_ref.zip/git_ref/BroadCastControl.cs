﻿/// <summary>
/// Copyright 奇点星空2015
///
/// Component Name: BroadCastControl
/// 
/// Author: Dr
///
/// Usage:
///      1、挂在Dummy身上
/// 
/// Require: 
///      1、AIControl、DummyPlayer
///
/// Mark:
///      1、此脚本主要功能：根据服务器下达的指令，控制AI层
///      2、新增功能首先考虑新加脚本（组件）的方式而不是修改这个脚本
///
/// Brief:
///      1、处理普通攻击、释放技能
///      2、处理Idle、Run
///
/// Log:
///      版本1： 目前仅提供基本命令的处理、后续待扩展
/// 
/// </summary>

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using com.jdxk;
using com.jdxk.Configs;
using com.jdxk.net.message;
using Events;
using UniverseX;

public class BroadCastControl : BaseObj, IPlayerData
{
    public BuffPool BuffPool
    {
        get
        {
            if (_BuffPool == null)
            {
                _BuffPool = new BuffPool(this);
            }
            return _BuffPool;
        }
    }

    protected BuffPool _BuffPool;

    #region param
    // 角色ID
    public int RoleId = -1;
    public int RoleType { get; set; }

    private int RoleStatus { get; set; }

    //角色归属（针对怪物）
    public int OwnerId { get; set; }
    public int OwnerType { get; set; }

    DummyPlayer _dummyPlayer;
    // 角色模型
    public DummyPlayer dummyPlayer
    {
        get
        {
            return _dummyPlayer;
        } 
        set
        {
            _dummyPlayer = value;
            _dummyPlayer.Fight = IsOnStatus(GameDefines.ROLE_STATUS_POS_FIGHT);
        }
    }

    //角色是否在屏幕中显示（针对同屏人数）
    private bool _bShowInScreen = true;
    public bool bShowInScreen
    {
        get { return _bShowInScreen; }
        set
        {
            _bShowInScreen = value;
            OnShowInScreenChanged();
        }
    }

    public OnTrailEvent trail = null;
    public Msg_FabaoInfo FabaoInfo { get; set; }  //法宝信息

    public int[] fabaoSkillIDArray = null;

    private GameObject fabaoObj = null;
    private GameObject wingObj = null;
    private Events.EventManager eventMgr = null;
    //
    public DummyPlayer soulPlayer = null;

    //针对其他玩家身上的元魂数据，如果是主角的请请用SoulManager里的。
    // 元魂数据
    public ArrayList SoulsInfo = new ArrayList();
    public int FightSoulId = -1;

    // 坐骑数据
    public IList<Msg_RideInfo> BeastsObtained = new List<Msg_RideInfo>();                       // 坐骑列表，暂时先放这里。
    public int DefaultBeast = -1;   // 默认坐骑

    //对应穿在身上的当前装备列表（Key代表装备位ID，对应EquipPos; Value代表装备位数据）
    public Dictionary<int, ItemData> Wear_EquipList = new Dictionary<int, ItemData>();

    //移动停止距离
    public float mStopRange { get; set; }
    // 角色碰撞盒
    protected CharacterController charControler;
    // NavMeshAgent 
    public GridNavPath.NavPathAgent agent = null;

    public int UsingSkillID = -1;
    //当前是否在随机喊话
    public bool isOnRandShoutOut = false;

    private int BC_TargetType = -1;//额，呵呵
    private int BC_TargetId = -1;//额，呵呵
    public void SetBCTarget(int type, int id)//额，呵呵
    {
        BC_TargetType = type;
        BC_TargetId = id;
    }
    public int VipLevel { get; set; }
    public int VipExp { get; set; }
    private float mSpeed;
    //速度
    public float speed
    {
        get
        {
            if (null != agent)
            {
                return agent.CurrentSpeed;
            }
            else
            {
                return mSpeed;
            } 
        }
        set
        {
            try
            {
                if (null != agent)
                {
                    agent.CurrentSpeed = value;
                    NavMeshAgent navMeshAgent = GetComponent<NavMeshAgent>();
                    navMeshAgent.speed = value;
                }
                else
                {
                    mSpeed = value;
                }
            }
            catch (UnityException uex)
            {
                LogManager.Log(uex.ToString(), LogType.Fatal);
            }
        }
    }

    private int mTeamId;
    private int mIsLeader;

    #endregion

    #region 获取状态
    public bool IsOnStatus(int status)
    {
        return (RoleStatus & status) > 0;
    }

    public virtual void OnStatus(int status)
    {
        RoleStatus |= status;
    }

    public virtual void EndStatus(int status)
    {
        RoleStatus &= ~status;
    }

    public virtual void SetStatus(int status, int modified, int[] param)
    {
        //不能直接设置，两边状态对不上, 直接设置会把客户端状态给清掉
        if ((status & modified) == 0)//去掉
        {
            EndStatus(modified);
        }
        else if ((status & modified) == modified)//加上
        {
            OnStatus(modified);
        }
        else
        {
        }

        if (modified == GameDefines.ROLE_STATUS_POS_NORMAL ||
            modified == GameDefines.ROLE_STATUS_POS_DEAD)
        { // 所有状态归0
     //       RoleStatus = status;
        }
        else
        {
            bool bHandled = false;
            //骑马这个状态服务器根本没广播, 注掉了，误导人
//             if ((modified & GameDefines.ROLE_STATUS_POS_RIDE) > 0)
//             {
//                 bHandled = true;
//                 if ((status & GameDefines.ROLE_STATUS_POS_RIDE) > 0 && null != param)
//                 { // 骑乘
//                     RideBase_Tbl tbl = ConfigPool.Instance.GetDataByKey<RideBase_Tbl>(param[GameDefines.OBJ_STATUS_RIDE]);
//                     RideManager.Ride(tbl.modelId[0], tbl.modelId[1], this);
//                 }
//                 else
//                 { // 下马
//                 }
//             }
            
            //目前不会走这个，防止出坑，先注掉
//             if ((modified & GameDefines.ROLE_STATUS_POS_SOUL) > 0)
//             {
//                 bHandled = true;
//                 if ((status & GameDefines.ROLE_STATUS_POS_SOUL) > 0)
//                 { // 元魂
//                     if (param != null)
//                     {
//                         SoulManager.ChangeSoul(param[GameDefines.OBJ_STATUS_SOUL], this);
//                     }
//                 }
//                 else
//                 { // 变回
//                     SoulManager.ResumeSoul(this);
//                 }
//             }
            
            if ((modified & GameDefines.ROLE_STATUS_POS_DIZZ) > 0)
            {
                bHandled = true;
                if ((status & GameDefines.ROLE_STATUS_POS_DIZZ) > 0)
                { // 眩晕
                    dummyPlayer.Dizz = true;
                }
                else
                { // 清醒
                    dummyPlayer.Dizz = false;
                }
            }

            if ((modified & GameDefines.ROLE_STATUS_POS_FIGHT) > 0)
            {
                bHandled = true;
                if ((status & GameDefines.ROLE_STATUS_POS_FIGHT) > 0)
                { //战斗状态
                    dummyPlayer.Fight = true;
                }
                else
                {
                    dummyPlayer.Fight = false;
                }
            }

            //石化状态
            if ((modified & GameDefines.ROLE_STATUS_POS_STONE) > 0)
            {
                bHandled = true;
                if ((status & GameDefines.ROLE_STATUS_POS_STONE) > 0)
                { // 石化
                    dummyPlayer.Stone = true;
                }
                else
                { // 正常
                    dummyPlayer.Stone = false;
                }
            }

            if ((modified & GameDefines.ROLE_STATUS_POS_MISSION) > 0)
            {
                bHandled = true;
                if ((status & GameDefines.ROLE_STATUS_POS_MISSION) > 0)
                { // 跑商

                }
                else
                { // 跑商完成

                }
            }

            if ((modified & GameDefines.ROLE_STATUS_POS_MUSIC) > 0)
            {
                bHandled = true;
                if ((status & GameDefines.ROLE_STATUS_POS_MUSIC) > 0)
                { // 演奏
                    BeginMusic();
                }
                else
                { // 演奏完成
                    EndMusic();
                }
            }

            if (!bHandled)//如果前边都没特殊处理就给个通用的处理
            {
                
            }

        }
    }

    #endregion
    
    public virtual void Init(DummyPlayer dummy)
    {
        try
        {
            Wear_EquipList.Clear();
            isTotalInfo = false;

            dummyPlayer = dummy;
            RoleType = (int)Enum_ObjType.OBT_PLAYER;
            eventMgr = new Events.EventManager();
            eventMgr.Init();
            charControler = GetComponent<CharacterController>();
            InitNavAgent();

            RoleStatus = GameDefines.ROLE_STATUS_POS_NORMAL;
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Fatal);
        }
    }

    public void updateEventList()
    {
        if (null != eventMgr) eventMgr.updateEvent(this);
    }
    //将事件压入队列
    public void PushEventToList(int nEType,int nSendId,int nSendType, int nSkillId,int nTickCount,
                                 int param1, int param2, int param3, int param4 )
    {
        if (null == eventMgr)
        {
            return;
        }
        try
        {
            NewEventTypes eType = (NewEventTypes)nEType;
            switch (eType)
            {
                case NewEventTypes.EVENT_TYPE_DAMAGE:
                    {
                        eventMgr.RegisterDamageEvent(nSendId, nSendType, param2, param1, nSkillId, param3, nTickCount);
                    }
                    break;
                case NewEventTypes.EVENT_TYPE_IMPACT:
                    {
                        eventMgr.RegisterImpactEvent(nSendId, nSendType, nSkillId, param1, param4, param2, param3, nTickCount);
                    }
                    break;
                default:
                    break;
            }
        }
        catch (System.Exception ex)
        {
            LogManager.Log(ex.Message, LogType.Fatal);
        }
        
    }

    public virtual bool CanRun()
    {
        return (!IsOnStatus(GameDefines.ROLE_STATUS_POS_SKILL) &&
                !IsOnStatus(GameDefines.ROLE_STATUS_POS_DEAD) &&
                !IsOnStatus(GameDefines.ROLE_STATUS_POS_DIZZ) &&
                !IsOnStatus(GameDefines.ROLE_STATUS_POS_STONE) &&
                !IsOnStatus(GameDefines.ROLE_STATUS_POS_OPERA)
                );
    }

    public virtual void Run(Vector3 point, GameDefines.RunType t, float fStopRange = 1.0f, bool bInTeamFollow = false)
    {
        try
        {
            mStopRange = fStopRange;
            switch (t)
            {
                case GameDefines.RunType.JoyStick:
                    if (CanRun())
                    {
                        dummyPlayer.Run = true;
                        charControler.Move(point * Time.deltaTime);
                        Utility.LookAtTargetImmediately(this, point);
                    }
                    break;
                case GameDefines.RunType.NavAgent:
                    if (CanRun())
                    {
                        dummyPlayer.Run = true;
                        NavMove(point);
                    }
                    break;
                default:
                    break;
            }
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Fatal);
        }
    }
    public void StopNavMove()
    {
        if (agent.enabled)
        {
            agent.Stop();
            agent.enabled = false;
        }
    }

    public virtual void StopMove()
    {
        dummyPlayer.Run = false;
        StopNavMove();

        if (bInFollow)
        {
            SyncPos2ServerInTeamFollow(Enum_MoveType.MST_STOP);
            bInFollow = false;
        }

        // 释放技能检测
        if (UsingSkillID > 0)
        {
            Skill(BC_TargetId, BC_TargetType, UsingSkillID);
        }

        //停止移动是高度修正
        Utility.AdjustYAxis(this);
    }

    #region 组队跟随，移动同步
    public bool bInFollow = false;
    const float _SyncPos2ServerInterver = 0.2f;
    float _SyncPos2ServerCD = 0f;
    void SyncPos2ServerInTeamFollow(Enum_MoveType t)
    {
        if (t == Enum_MoveType.MST_STOP || _SyncPos2ServerCD <= 0)
        {
            _SyncPos2ServerCD = _SyncPos2ServerInterver;
            SceneManager.Instance.SyncPositionInTeamFollow(playerId, this.GetPosition(), this.GetRotation(), (int)t, 0);
        }
        else
        {
            _SyncPos2ServerCD -= Time.deltaTime;
        }
    }

    void LateUpdate()
    {
        if (bInFollow)
        {
            if (TeamModel.Instance.TeamFollowList.Contains(playerId))
            {
                SyncPos2ServerInTeamFollow(Enum_MoveType.MST_SYNC);
            }
            else
            {
                bInFollow = false;
            }
        }
    }
    #endregion

    public virtual void StopAllAction()
    {
        //停止可能的移动
        StopMove();
        //恢复站立状态---即停止所有活动，包括放技能
        dummyPlayer.Skill = -1;
    }
    public virtual void NavMove(Vector3 point)
    {
        point.y = Utility.GetNavMeshHeight(point);
        float dis = MathUtility.CalcDistance2D(point, GetPosition());
        if (!Utility.IsSamePosition2D(point, GetPosition()) && (dis > mStopRange))
        {
            dummyPlayer.Run = true;
            agent.startMove(transform, point, true);
            agent.ResetNextPosition();
        }
        else
        {
            StopMoveCallBack();
            StopMove();
        }
    }

    public virtual void Skill(int targetid, int targetType, int sId)
    {
        try
        {
            BroadCastControl TarObj = ObjectManager.Instance.GetCharObjControl(targetType, targetid);
            //对于其他玩家有可能骑马信息同步和放技能是同时的，人会在马上放技能，，，一个补救
            if (null != TarObj && TarObj.IsOnStatus(GameDefines.ROLE_STATUS_POS_RIDE))
            {
                TarObj.EndStatus(GameDefines.ROLE_STATUS_POS_RIDE);
                RideManager.UnRide(this);
            }

            dummyPlayer.UseSkill(sId, TarObj);
            UsingSkillID = -1;
            SetBCTarget(-1, -1);
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Fatal);
        }
    }

    public virtual void ReciveImpact(int nBuffId, int nBuffIndex, int nStackCount, int nLifeTime, BroadCastControl fromPlayer)
    {
        if (!IsOnStatus(GameDefines.ROLE_STATUS_POS_DEAD))
        {
            BuffPool.AddBuff(nBuffId, nBuffIndex);
        }
    }

    //收到伤害的处理
    public virtual void Hit(int currHP, int damageHP, int damageFlag, BroadCastControl fromPlayer, int skillId)
    {
        try
        {
            curHp = currHP;
            if ((null != fromPlayer && fromPlayer.RoleId == PersonControl.Instance.RoleId) || //客户端自己打出的伤害
                 RoleId == PersonControl.Instance.RoleId)//客户端自己受到伤害
            {
                //Debug.Log("From:" + fromPlayer.name + "(" + fromPlayer.playerId + ")" + " To:" + dummyPlayer.name + " Damage is" + damageHP + " SkillID is " + skillId);
                //如果是非战斗伤害,考虑直接播出来(比如buff)
                dummyPlayer.BeHit(damageFlag, damageHP, skillId);
            }
            //死了, 确保他死亡
            if (curHp <= 0)
            {
                Die(fromPlayer);
            }
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Fatal);
        }
    }

    public virtual void Die(BroadCastControl player)
    {
        // 去除主角的目标
        PersonControl.Instance.ClearTargetEnemy(this);

        // 停止寻路
        StopMove();
        // 清除骑乘状态
        RideManager.UnRide(this);
        // 清队元魂状态
        SoulManager.ResumeSoul(this);

        // 逻辑上的死亡
        SetStatus(GameDefines.ROLE_STATUS_POS_DEAD, GameDefines.ROLE_STATUS_POS_DEAD, null);
        // 表现上的死亡
        dummyPlayer.Dead = true;
    }

    void OnDestroy()
    {
        if (dummyPlayer != null)
        {
            dummyPlayer.Clear();
        }
        if(nameBoard != null)
        {
            nameBoard.showInfo(false);
        }
        StopCoroutine("DelShoutTime");
    }

    public virtual void Relive(float posX, float posY, float posZ, int hp, int mp)
    {
        RoleStatus = GameDefines.ROLE_STATUS_POS_NORMAL;

        dummyPlayer.Dead = false;
        dummyPlayer.ResetAnimator();

        //复活时也同时设置一下血量
        this.curHp = hp;
        this.curMp = mp;

        SetPosition(new Vector3(posX, posY, posZ));
        Utility.AdjustYAxis(this);

        if (this is PersonControl)
        {
            if (UIControl.Instance.PanelManager.GetPanel(Panels.DeadPanel) != null)
            {
                DeadPanel deadPanel = UIControl.Instance.PanelManager.GetPanel(Panels.DeadPanel) as DeadPanel;

                deadPanel.Close();
            } else if(UIControl.Instance.PanelManager.GetPanel(Panels.GangFightDeadPanel) != null)
            {
                GangFightDeadPanel deadPanel = UIControl.Instance.PanelManager.GetPanel(Panels.GangFightDeadPanel) as GangFightDeadPanel;
                deadPanel.Close();
            }
        }
    }

    protected override void SelfStart()
    {
        
    }

    protected override void SelfUpdate()
    {
        try
        {
            if (null != dummyPlayer)
            {
                if (dummyPlayer.Run)
                {
                    if (Utility.IsSamePosition2D(GetPosition(), agent.destination))
                        StopMove();
                    else
                    {
                        //停下的逻辑
                        float dis = MathUtility.CalcDistance2D(agent.destination, GetPosition());
                        if (dis <= mStopRange)
                        {
                            StopMove();
                        }
                    }
                }
            }
            //处理事件缓存
            updateEventList();

            RefreshNameBoard();
        }
        catch (UnityException e)
        {
            LogManager.Log("BroadCaseControl,SelfUpdate Error: " + e.StackTrace, LogType.Error);
        }
    }

    protected virtual void StopMoveCallBack()
    {

    }

    public virtual void Ride()
    {

    }

    public virtual void ChangeSoul()
    {

    }

    public virtual void InitNavAgent()
    {
        if (agent == null)
        {
            agent = new GridNavPath.NavPathAgent();
            agent.InitAgent(gameObject);
        }
    }

    //NameBoard
    public GameObject nameBoardObj = null;
    public NameBoard nameBoard;
    public virtual bool CreateNameBoard()
    {
        try
        {
            if (nameBoardObj != null)
            { //已经加了还加毛啊
                return false;
            }

            if (HUDRoot.go == null)
            {
                return false;
            }

            Transform hintPointTrans = Utility.FindBone(this.transform, GameUtility.enBone.Bone_HintPoint);
            Transform headPointTrans = Utility.FindBone(this.transform, GameUtility.enBone.Bone_Head);

            if (null == hintPointTrans && headPointTrans == null)
            {
                return false;
            }

            nameBoardObj = UIPrefabPoolUtil.Instance.GetUIObjByName(UIPrefabPoolUtil.NameBoard, HUDRoot.go);
            nameBoard = nameBoardObj.GetComponent(typeof(NameBoard)) as NameBoard;

            UIFollowTarget ft = nameBoardObj.AddComponentEx<UIFollowTarget>();

            if (null == hintPointTrans)
                ft.target = headPointTrans.transform;
            else
                ft.target = hintPointTrans;

            ft.gameCamera = Camera.main;
            ft.uiCamera = UIControl.CameraUI;
            ft.disableIfInvisible = false;
            ft.SetVisible(false);

            return true;
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Error);
        }
        catch (System.Exception ex)
        {
            LogManager.Log(ex.ToString(), LogType.Error);
        }

        return false;
    }

    void RefreshNameBoard()
    {
        if (null == nameBoardObj && !string.IsNullOrEmpty(charName))
        {
            CreateOtherPlayerNameBoard();
            ObjectManager.Instance.RefeshNameBoard(this);
            SetPlayerTeamIcon(mTeamId, mIsLeader);
        }
        else
        {
            if (null != nameBoard)
            {
                nameBoard.RefeshIconPos();
            }
        }
    }

    public void RecycleNameBoard()
    {
        if (null != nameBoard && null != nameBoardObj)
        {
            UIPrefabPoolUtil.Instance.DespawnUIObj(nameBoardObj.transform);
        }
    }

    public void CreateOtherPlayerNameBoard()
    {
        if (CreateNameBoard())
        {
            dummyPlayer.dummyType = GameDefines.DummyType.PlayerSelf;
            nameBoard.SetNameBoard(charName, "", dummyPlayer.dummyType);
        }
    }

    #region 变身元魂、骑乘坐骑后适配名字版位置
    public void RefreshPlayerNameBoard(Transform trans)
    {
        Transform headPoint = Utility.FindBone(trans, GameUtility.enBone.Bone_Head);
        if(null != headPoint && null != nameBoard)
        {
            nameBoard.RefreshFollowTarget(headPoint);
        }
    }

    public void RefeshPlayerNameBoradForRide(Transform trans)
    {
        Transform headPoint = FindBone(trans, GameUtility.GetBoneName(GameUtility.enBone.Bone_Head));
        if (null != headPoint && null != nameBoard)
        {
            nameBoard.RefreshFollowTarget(headPoint);
        }
    }

    private Transform FindBone(Transform trans, string name)
    {
        if (trans.name == "qichengdian")
            return null;

        if (trans.name == name)
            return trans;

        for (int i = 0; i < trans.childCount; ++i)
        {
            Transform bone = FindBone(trans.GetChild(i), name);
            if (null != bone)
                return bone;
        }

        return null;
    }
    #endregion

    public void RefeshPlayerTitle()
    {
        if(null != nameBoard)
        {
            nameBoard.RefreshPlayerTitle(this);
        }
    }

    public void RefeshGangInfo()
    {
        if (null != nameBoard)
        {
            nameBoard.RefreshGangInfo(this);
        }
    }

    public void SetOtherPlayerNameColor(Enum_PKModeType pkMode)
    {
        if (nameBoard != null)
        {
            nameBoard.SetOtherPlayerNameColor(pkMode, this);
        }
    }

    public void setPlayerVipLevel()
    {
        if (nameBoard != null)
        {
            nameBoard.SetPlayerVipLevel(this);
        }
    }

    public void SetPlayerTeamIcon(int teamId, int isLeader)
    {
        mTeamId = teamId;
        mIsLeader = isLeader;
        if (nameBoard != null)
        {
            if(teamId > 0)
            {
                nameBoard.ShowTeamIcon(isLeader > 0);
            }
            else
            {
                nameBoard.HideTeamIcon();
            }
        }
    }

    public void InitWearList(IList<Msg_ItemData> wearList)
    {
        for (int i = 0; i < (int)ItemDef.EquipPos.Length; i++)
        {
            if (!Wear_EquipList.ContainsKey(i))
                Wear_EquipList.Add(i, null);
            else
                Wear_EquipList[i] = null;
        }

        //穿戴数据赋值
        for (int i = 0; i < wearList.Count; i++)
        {
            ItemData itemData = new ItemData();
            if (itemData.Init(wearList[i]))
            {
                Item_Tbl item_tbl = BagUtility.GetConfigItem(wearList[i].TemplateId);
                if (null != item_tbl)
                {
                    Wear_EquipList[item_tbl.subType] = itemData;
                }
            }
        }
    }

    public void CreateFabaoObj(int fabaoShowId,int type = 0) //type = 0 (默认) type = 1
    {
        try
        {
            if (fabaoShowId <= 0)
            {
                return;
            }

            Transform headRoot = Utility.FindBone(this.transform, GameUtility.enBone.Bone_Head);

            if (headRoot != null)
            {
                if (fabaoObj != null)
                {
                    GameObject.Destroy(fabaoObj);
                }

                FabaoBase_Tbl fabaoBase = ConfigPool.Instance.GetDataByKey<FabaoBase_Tbl>(fabaoShowId);
                if(fabaoBase == null)
                {
                    return;
                }
                fabaoObj = BundleResource.GetMe().GetResourceInstance(fabaoBase.modelId);

                FollowTargetInWorld follow = fabaoObj.AddComponentEx<FollowTargetInWorld>();

                follow.target = headRoot;
                if(type == 0)
                {
                    follow.offset = RideManager.IsRiding(this) ? new Vector3(0.44f, -0.73f, 0f) : new Vector3(0.44f, 0f, 0f);
                    fabaoObj.transform.position = headRoot.position + follow.offset;
                    follow.strength = 4f;
                    fabaoObj.transform.localScale = Vector3.one;
                    //法宝特效显隐
                    if (this.playerId == PersonControl.Instance.playerId)
                    {
                        SetFaBaoEffectShowStatus(RuntimeSettings.ShowSelfFaBaoEffect);
                    }
                    else
                    {
                        SetFaBaoEffectShowStatus(RuntimeSettings.ShowOtherFaBaoEffect);
                    }
                    //同屏人数，控制法宝显隐
                    SetFabaoShowStatus();
                }
                else if (type == 1)
                {
                    follow.offset = RideManager.IsRiding(this) ? new Vector3(0.8f, -0.35f, 0f) : new Vector3(0.8f, -0.35f, 0f);
                    fabaoObj.transform.position = headRoot.position + follow.offset;
                    follow.strength = 4f;

                    fabaoObj.transform.localScale = Vector3.one;
                    if (fabaoObj != null)
                    {
                        Transform trans = Utility.FindBone(fabaoObj.transform, "fabaotexiaodian");
                        if (null != trans)
                        {
                            fabaoObj.layer = LayerMask.NameToLayer(GameDefines.LayerUIModel);
                            NGUITools.SetChildLayer(fabaoObj.transform, LayerMask.NameToLayer(GameDefines.LayerUIModel));
                        }
                    }
                }
            }
        }
        catch (UnityException ue)
        {
            LogManager.Log(ue.ToString(), LogType.Error);
        }
    }
    public void OnPlayerRideHandle()
    {
        if (fabaoObj != null)
        {
            FollowTargetInWorld follow = fabaoObj.GetComponent<FollowTargetInWorld>();
            follow.offset = new Vector3(0.44f, -0.73f, 0f); 
        }
    }

    public void OnPlayerUnRideHandle()
    {
        if (fabaoObj != null)
        {
            FollowTargetInWorld follow = fabaoObj.GetComponent<FollowTargetInWorld>();
            follow.offset = new Vector3(0.44f, 0f, 0f);
        }
    }

    public void SetFabaoShowStatus(bool bVisible)
    {
        if (fabaoObj != null)
        {
            NGUITools.SetLayer(fabaoObj, bVisible ? LayerMask.NameToLayer(GameDefines.LayerDefault) : LayerMask.NameToLayer(GameDefines.LayerAirBall));
        }

        SetFabaoShowStatus();
    }

    //同屏显示相关、显隐法宝
    public void SetFabaoShowStatus()
    {
        if (fabaoObj != null && fabaoObj.layer != LayerMask.NameToLayer(GameDefines.LayerAirBall))
        {
            NGUITools.SetLayer(fabaoObj, bShowInScreen ? LayerMask.NameToLayer(GameDefines.LayerDefault) : LayerMask.NameToLayer(GameDefines.LayerAirBall));
        }
    }

    public void SetFaBaoEffectShowStatus(bool bVisible)
    {
        if (fabaoObj != null)
        {
            Transform trans = Utility.FindBone(fabaoObj.transform, "fabaotexiaodian");
            if (null != trans)
            {
                NGUITools.SetLayer(trans.GetChild(0).gameObject, bVisible ? LayerMask.NameToLayer(GameDefines.LayerDefault) : LayerMask.NameToLayer(GameDefines.LayerAirBall));
            }
        }
    }

    public void CreateWingObj(int preWingId, int curWingId)
    {
        if (curWingId <= 0)
        {
            return;
        }

        try
        {
            WingBase_Tbl curWingBase = ConfigPool.Instance.GetDataByKey<WingBase_Tbl>(curWingId);
            bool bAddWing = false;

            if (preWingId <= 0)
            {
                bAddWing = true;
            }
            else
            {
                WingBase_Tbl preWingBase = ConfigPool.Instance.GetDataByKey<WingBase_Tbl>(preWingId);

                if (preWingBase == null || curWingBase == null)
                {
                    return;
                }

                bAddWing = preWingBase.modelId != curWingBase.modelId;
            }

            if (bAddWing)
            {
                //翅膀的默认资源ID
                int resID = curWingBase.modelId;

                //获取翅膀挂点
                Transform wingEffectPoint = Utility.FindBone(transform, GameUtility.enBone.Bone_Wing);
                
                //换翅膀上去喽
                Utility.DeleteObjsChildrenImmediate(wingEffectPoint);
                wingObj = Utility.EquipObj(resID, wingEffectPoint);
                if (wingObj)
                {
                    wingObj.AddComponent<FakeAniStart>();
                }
                SetWingShowStatus();

                if (this is PersonControl)
                {
                    ModelPanel modelPanel = UIControl.GetPanel(Panels.ModelPanel) as ModelPanel;
                    if (null != modelPanel)
                    {
                        //换模型展示面板的翅膀
                        modelPanel.CreateWingObj(curWingId);
                    }
                }
            }
        }
        catch (UnityException ue)
        {
            LogManager.Log(ue.ToString(), LogType.Error);
        }
    }

    public void DeleteWingObj()
    {
        //获取翅膀挂点
        Transform wingEffectPoint = Utility.FindBone(dummyPlayer.transform, GameUtility.enBone.Bone_Wing);

        //换翅膀上去喽
        Utility.DeleteObjsChildrenImmediate(wingEffectPoint);

        ModelPanel modelPanel = UIControl.GetPanel(Panels.ModelPanel) as ModelPanel;
        if (null != modelPanel)
        {
            //换模型展示面板的翅膀
            modelPanel.DeleteWingObj();
        }
    }

    //同屏显示相关、显隐翅膀
    public void SetWingShowStatus()
    {
        if (wingObj != null)
        {
            NGUITools.SetLayer(wingObj, bShowInScreen ? LayerMask.NameToLayer(GameDefines.LayerDefault) : LayerMask.NameToLayer(GameDefines.LayerAirBall));
        }
    }

    public void SetTimeCountDown(int leftTime)
    {
        if (null == nameBoard)
        {
            CreateNameBoard();
        }

        if (leftTime > 0)
        {
            string str = string.Format("倒计时{0}", leftTime);
            nameBoard.SetNameBoard(str, dummyPlayer.dummyType);
        }
        else
        {
            nameBoard.SetNameBoard("", dummyPlayer.dummyType);
        }
    }

    /// <summary>
    /// 是否是杀手玩家者
    /// </summary>
    public bool IsEvilKiller()
    {
        if (killPoint >= GameDefines.KILLER_KILLPOINT_NUM)
            return true;
        return false;
    }

    /// <summary>
    /// 是否是同一个阵营的玩家
    /// </summary>
    public bool IsInDiffCamp(int campId)
    {
        if (this.campId != (int)Enum_Camp.Camp_Middle && campId != (int)Enum_Camp.Camp_Middle && campId != this.campId)
            return true;
        return false;
    }

    public override void SetPosition(Vector3 pos)
    {
        if (null != agent)
            agent.CloseAgent();
        transform.position = pos;
    }

    #region 玩家数据
    public bool isInit { get; set; }

    public bool isTotalInfo { get; set; }

    public int playerId { get; set; }
    public string charName { get; set; }
    public long guid { get; set; }
    public int careerId { get; set; }		    // 职业
    public int sexId { get; set; }              // 性别
    public int level { get; set; }		        // 等级
    public int con { get; set; }	            // 体质
    public int strength { get; set; }		    // 力量
    public int spirit { get; set; }		        // 元气
    public int agility { get; set; }		    // 敏捷
    public int maxhp { get; set; }		        // 血量
    public int curHp { get; set; }		        // 当前血量值
    public int maxmp { get; set; }		        // 魔法值
    public int curMp { get; set; }	            // 当前魔法值
    public int pAtk { get; set; }		        // 物理攻击
    public int mAtk { get; set; }			    // 法术攻击
    public int pDef { get; set; }			    // 物理防御
    public int mDef { get; set; }			    // 法术防御
    public int hit { get; set; }		        // 命中
    public int miss { get; set; }	            // 闪避
    public int crit { get; set; }		        // 暴击
    public int critResist { get; set; }	        // 暴抗
    public int critIncreased { get; set; }      // 暴击加深
    public int critReduction { get; set; }      // 暴击减免
    public int through { get; set; }		    // 穿透
    public int patty { get; set; }		        // 格挡
    public int criticalHit { get; set; }	    // 神圣一击
    public int strDefuse { get; set; }			// 御劲化解
    public int damageInc { get; set; }	        // 伤害加深
    public int damageRedu { get; set; }	        // 伤害减免

    public int iceAtk { get; set; }	            // 冰攻击
    public int iceResist { get; set; }	        // 冰抗性
    public int iceRedu { get; set; }	        // 冰减抗
    public int fireAtk { get; set; }	        // 火攻击
    public int fireResist { get; set; }	        // 火抗性
    public int fireRedu { get; set; }	        // 火减抗
    public int rayAtk { get; set; }	            // 雷攻击
    public int rayResist { get; set; }	        // 雷抗性
    public int rayRedu { get; set; }	        // 雷减抗
    public int poisonAtk { get; set; }	        // 毒攻击
    public int poisonResist { get; set; }	    // 毒抗性
    public int poisonRedu { get; set; }	        // 毒减抗


    public int weaponId { get; set; }		    // 武器id
    public int weaponStarLevel { get; set; }	// 武器精炼等级
    public int clothesId { get; set; }			// 衣服id

    public long gangId { get; set; }		    // 帮会id
    public string gangName { get; set; }		// 帮会名字

    public int gangCamp { get; set; }           //帮会阵营
    public int atkSpeed { get; set; }			// 攻击速度
    public int pkMode { get; set; }             // Pk模式
    public int fabaoId { get; set; }            //法宝id
    public int soulId{get;set;}                 //元魂id
    public int partnerId { get; set; }          //坐骑id
    public int wingId { get; set; }             //翅膀id
    public int campId { get; set; }         //阵营Id
    public int combatPower { get; set; }        //战斗力
    public int killPoint { get; set; }          //杀戮值

	public int titleID { get; set; }			// 显示的称号id

    public int fightCamp { get; set; }		// 阵营

    public int weekCharm { get; set; } //周魅力值

    public int totalCharm { get; set; } //总魅力值
    public int flowerCount { get; set; }//当前身上的花朵数
	public string jieYiName { get; set; }		// 结义总名
	public string jieYiSubName { get; set; }		// 结义个人名
	public long jieYiTime { get; set; }		// 结义时间
	public string mateName { get; set; }		// 配偶名
	public long marriageTime { get; set; }		// 结婚时间

    public void SetPlayerDetailAttrInfo(Msg_HumanBaseInfo attrInfo)
    {
        if (null != attrInfo)
        {
            con = attrInfo.Con;
            strength = attrInfo.Strength;
            spirit = attrInfo.Spirit;
            agility = attrInfo.Agility;
            maxhp = attrInfo.MaxHp;
            curHp = attrInfo.CurHp;
            maxmp = attrInfo.MaxMp;
            curMp = attrInfo.CurMp;
            pAtk = attrInfo.PAtk;
            mAtk = attrInfo.MAtk;
            pDef = attrInfo.PDef;
            mDef = attrInfo.MDef;
            hit = attrInfo.Hit;
            miss = attrInfo.Miss;
            crit = attrInfo.Crit;
            critResist = attrInfo.CritResist;
            critIncreased = attrInfo.CritIncreased;
            critReduction = attrInfo.CritReduction;
            criticalHit = attrInfo.CriticalHit;
            patty = attrInfo.Patty;
            through = attrInfo.Through;
            strDefuse = attrInfo.StrDefuse;
            damageInc = attrInfo.DamageInc;
            damageRedu = attrInfo.DamageRedu;
            iceAtk = attrInfo.IceAtk;
            iceResist = attrInfo.IceResist;
            iceRedu = attrInfo.IceRedu;
            fireAtk = attrInfo.FireAtk;
            fireResist = attrInfo.FireResist;
            fireRedu = attrInfo.FireRedu;
            rayAtk = attrInfo.RayAtk;
            rayRedu = attrInfo.RayRedu;
            rayResist = attrInfo.RayResist;
            poisonAtk = attrInfo.PoisonAtk;
            poisonResist = attrInfo.PoisonResist;
            poisonRedu = attrInfo.PoisonRedu;
        }
    }
    //请求玩家的基本信息 
    public virtual void SetPlayerBaseInfo(Msg_PlayerBaseInfo baseInfo)
    {
        isTotalInfo = true;
        isInit = true;  //记录是否初始化
        playerId = baseInfo.PlayerId;
        charName = baseInfo.CharName;
        guid = baseInfo.PlayerGuid;
        careerId = baseInfo.CareerId;
        sexId = baseInfo.SexId;
        level = baseInfo.Level;
        weaponId = baseInfo.WeaponId;
        weaponStarLevel = baseInfo.WeaponStarLevel;
        clothesId = baseInfo.ClothesId;
        gangId = baseInfo.GangId;
        gangName = baseInfo.GangName;
        atkSpeed = baseInfo.AtkSpeed;
        RoleId = playerId;
        speed = System.Convert.ToSingle(baseInfo.MoveSpeed) / 100f;
        atkSpeed = baseInfo.AtkSpeed;
        //新加的属性
        pkMode = baseInfo.PkMode;
        fabaoId = baseInfo.FabaoId;
        wingId = baseInfo.WingId;
        VipLevel = baseInfo.VipLevel;
        combatPower = baseInfo.CombatPower;
        campId = baseInfo.CampId;
        killPoint = baseInfo.KillPoint;
        if (baseInfo.HasAttrInfo) 
        {//属性信息
            SetPlayerDetailAttrInfo(baseInfo.AttrInfo);
        }
        fightCamp = baseInfo.FightCamp;
        weekCharm = baseInfo.WeekCharm;
        totalCharm = baseInfo.TotalCharm;
        flowerCount = baseInfo.FlowerCount;
		jieYiName = baseInfo.JieYiName;
		jieYiSubName = baseInfo.JieYiSubName;
		jieYiTime = baseInfo.JieYiTime;
		mateName = baseInfo.MateName;
		marriageTime = baseInfo.MarriageTime;
    }
    //客户端定时发送请求
    public void SetOtherBaseInfo(Msg_OtherPlayerInfo baseInfo)
    {
        isInit = true;  //记录是否初始化
        playerId = baseInfo.PlayerId;
        charName = baseInfo.CharName;
        guid = baseInfo.PlayerGuid;
        careerId = baseInfo.CareerId;
        sexId = baseInfo.SexId;
        level = baseInfo.Level;
        curHp = baseInfo.CurHp;
        fabaoId = baseInfo.FabaoId;
        wingId = baseInfo.WingId;
        VipLevel = baseInfo.VipLevel;
        if (curHp <= 0 && !IsOnStatus(GameDefines.ROLE_STATUS_POS_DEAD))
        {
            Die(null);
        }
        weaponId = baseInfo.WeaponId;
        weaponStarLevel = baseInfo.WeaponStarLevel;
        clothesId = baseInfo.ClothesId;
        gangId = baseInfo.GangId;
        gangName = baseInfo.GangName;
        gangCamp = baseInfo.GangCamp;
        RoleId = playerId;
        speed = System.Convert.ToSingle(baseInfo.MoveSpeed) / 100f;
        pkMode = baseInfo.PkMode;
        campId = baseInfo.CampId;
        killPoint = baseInfo.KillPoint;
		titleID = baseInfo.TitleShowId;
        fightCamp = baseInfo.FightCamp;
        flowerCount = baseInfo.FlowerCount;
		jieYiName = baseInfo.JieYiName;
		jieYiSubName = baseInfo.JieYiSubName;
		mateName = baseInfo.MateName;
		marriageTime = baseInfo.MarriageTime;

        for (int i = 0; i < baseInfo.buffListCount / 2; ++i)
        {
            ReciveImpact(baseInfo.GetBuffList(2 * i), baseInfo.GetBuffList(2 * i + 1), 1, 0, null);
        }
    }

    public void RefeshOtherBaseInfo(Msg_PlayerBaseInfoForTick baseInfo)
    {
        playerId = baseInfo.PlayerId;
        level = baseInfo.Level;
        curHp = baseInfo.CurHp;
        curMp = baseInfo.CurMp;
        maxhp = baseInfo.MaxHp;
        maxmp = baseInfo.MaxMp;
        if (curHp <= 0 && !IsOnStatus(GameDefines.ROLE_STATUS_POS_DEAD))
        {
            Die(null);
        }
        RoleId = playerId;
        speed = System.Convert.ToSingle(baseInfo.MoveSpeed) / 100f;
        killPoint = baseInfo.KillPoint;
    }

    #endregion

    #region 同屏显示相关

    public void OnShowInScreenChanged()
    {
        if (this.RoleType == (int)Enum_ObjType.OBT_PLAYER)
        {
            //坐骑、元魂、玩家自身
            OnDummyChange();
            //法宝
            SetFabaoShowStatus();
            //翅膀
            SetWingShowStatus();
        }
    }

    public void OnDummyChange()
    {
        NGUITools.SetLayer(dummyPlayer.gameObject, bShowInScreen ? LayerMask.NameToLayer(GameDefines.LayerModel) : LayerMask.NameToLayer(GameDefines.LayerAirBall));
    }

    #endregion

    public enum HandleEventType
    {
        AE_CanBreakSkill,
        AE_CanNotBreakSkill,
        AE_AnimStart,
        AE_EndSkill,
        EnterScene,
        AE_UseSkill,
    }

    bool isPause = false;//是否被打断
    public virtual void HandleEvent(HandleEventType e)
    {
       
    }
    #region 喊话相关
    public void Shout_Out(string what,int index,int type) //type = 0 随机 type = 1 服务器指定喊话
    {
        if(SequenceManager.Instance != null && SequenceManager.Instance.IsPlaying())
        {
            return;
        }

        isPause = false;
        nameBoard.setShoutOutInfo(this,what);
        Invoke("Shout",index * 1.2f);
        if (type == 0)
        {
            isOnRandShoutOut = true;
        }
    }
    void Shout()
    {
        if (isPause)
        {
            return;
        }
        nameBoard.showInfo(true);
        StartCoroutine("DelShoutTime",5f);
    }
    //喊话持续 默认 5 秒
    IEnumerator DelShoutTime(float time)
    {
        yield return new WaitForSeconds(time);
        nameBoard.showInfo(false);
        nameBoard.setShoutOutInfo(this);
        isOnRandShoutOut = false;    
    }
    //停止当前喊话
    public void StopCurShout_Out()
    {
        if (isOnRandShoutOut)
        {
            nameBoard.showInfo(false);
            nameBoard.setShoutOutInfo(this);
            isOnRandShoutOut = false;
            isPause = true;
        }
    }

    #endregion
    public bool judgeCamp(BroadCastControl to, int camp)
    {
        if (to == null || to.fightCamp <= 0)
        {
            return false;
        }

        FightCamp_Tbl db = ConfigPool.Instance.GetDataByKey(typeof(FightCamp_Tbl), fightCamp) as FightCamp_Tbl;
        if (db != null)
        {
            if ((to.fightCamp-1) < db.relation.Length && db.relation[to.fightCamp-1] == camp)
            {
                return true;
            }
        }

        return false;
    }

    public void RefreshFlowerIcon()
    {
        if(nameBoard != null)
        {
            nameBoard.RefreshFlowerIcon(flowerCount);
        }
    }

    #region 演奏相关

    //检测是否可以演奏
    public virtual bool CheckCanMusic(bool bShowFloatTips = true)
    {
        return true;
    }

    //开始演奏
    public virtual void BeginMusic()
    {
        int resId = 0;
        int musicResId = 0;

        //隐藏武器
        Transform leftWeaponPoint = Utility.FindBone(dummyPlayer.transform, GameUtility.enBone.Bone_LeftHand);
        Transform rightWeaponPoint = Utility.FindBone(dummyPlayer.transform, GameUtility.enBone.Bone_RightHand);
        Utility.DeleteObjsChildrenImmediate(leftWeaponPoint);
        Utility.DeleteObjsChildrenImmediate(rightWeaponPoint);

        //显示乐器
        if (sexId == (int)GameDefines.SexType.Male)
        {
            //男
            resId = 40120;
            musicResId = 30227;
            Utility.EquipObj(resId, rightWeaponPoint);
        }
        else if(sexId == (int)GameDefines.SexType.Female)
        {
            //女
            resId = 40420;
            musicResId = 30228;
            Transform footPoint = Utility.FindBone(dummyPlayer.transform, GameUtility.enBone.Bone_Foot);
            Utility.EquipObj(resId, footPoint);
        }

        //音效
        AudioClip clip = SoundHelper.GetMe().PlaySound(musicResId, true);
        if (null != clip)
        {
            if (SceneManager.Instance.musicAudioClipDic.ContainsKey(RoleId))
            {
                SceneManager.Instance.musicAudioClipDic[RoleId] = clip;
            }
            else
            {
                SceneManager.Instance.musicAudioClipDic.Add(RoleId, clip);
            }
        }

        //动作
        dummyPlayer.music = true;
    }

    public virtual void EndMusic()
    {
        if (sexId == (int)GameDefines.SexType.Female)//坑爹，女性角色挂在脚下了
        {
            Transform footPoint = Utility.FindBone(dummyPlayer.transform, GameUtility.enBone.Bone_Foot);
            Utility.DeleteObjsChildrenImmediate(footPoint);
        }

        SceneManager.Instance.StopMusicClip(RoleId);
        GetRealDp(this).music = false;
    }

    private DummyPlayer GetRealDp(BroadCastControl playerObj)
    {
        DummyPlayer dp = playerObj.dummyPlayer;
        if (dp is DummyBeast)
            return ((DummyBeast)dp).PlayerDummy;
        return dp;
    }

    #endregion
}
