﻿/// <summary>
/// 
/// Copyright 奇点星空2015
///
/// Class Name: DummyPlayer
/// 
/// Author: DK
///
/// Usage:
///      1、所有角色的表现层
///      2、播放动作，播放特效，装备换装等。
/// 
/// Mark:
///      1、BroadcastControl完成逻辑层的功能，DummyPlayer完成表现层的功能
///
/// Brief:
///
/// Log:
///     1、重构，2015-07-02，Kant
/// 
/// </summary>

using UnityEngine;
using com.jdxk;
using System.Collections;
using System.Collections.Generic;
using com.jdxk.net.message;
using com.jdxk.Configs;
using HighlightingSystem;
using UniverseX;

/// <summary>
/// 角色组件
/// </summary>
public class DummyPlayer : MonoBehaviour
{
    #region 参数
    public BroadCastControl PlayerObj = null;       // 玩家的逻辑实体
    public BroadCastControl TargetObj = null;       // 放技能的目标
    public int SkillID = -1;                        // 施放的技能

    public int modelId = -1;
    public int replaceModeId = -1;
    public int PKMode { get; set; }

    public int TargetCampId { get; set; }
	public GameDefines.DummyType dummyType;

    private HUDTextManager.TextType textType = HUDTextManager.TextType.NORMAL;

    //换装相关
    public bool IsWearOnDefaultTexture = true;    //是否穿戴默认的Texture
    public bool IsWareOnDefaultMesh = true;       //是否穿戴默认的Mesh

    #endregion

    #region 动作
    // Animator
    protected Animator animator;

    #region 
    const float hlShowTime = 5f;
    float hlCounter = -1f;
    bool autoOff = true;
    public Highlighter highlighter = null;
    Transform mTransform = null;

    Highlighter InitHighlighter()
    {
        if (!MainCameraCtrl.UseHighlight || !SystemInfo.supportsImageEffects)
        {
            return null;
        }

        //加到什么上必须要明确，不能随便加在最上层
        if (highlighter == null)
        {
            SkinnedMeshRenderer sm = mTransform.GetComponentInChildren<SkinnedMeshRenderer>();
            if (sm != null)
            {
                highlighter = sm.gameObject.AddComponentEx<Highlighter>();
            }

            if (highlighter != null)
            {
                highlighter.enabled = false;
            }
        }

        return highlighter;
    }

    public void HighlightConstantOn(Color col, float time = 0f, bool immediate = false)
    {
        if (InitHighlighter() == null)
        {
            return;
        }

        hlCounter = time;
        autoOff = time > 0f;

        if (immediate)
        {
            highlighter.ConstantOnImmediate(col);
        }
        else
        {
            highlighter.ConstantOn(col);
        }

        highlighter.enabled = true;
    }

    public void HighlightConstantOff(bool immediate = false)
    {
        if (highlighter == null)
        {
            return;
        }

        if (immediate)
        {
            highlighter.ConstantOffImmediate();
        }
        else
        {
            highlighter.ConstantOff();
        }

        highlighter.enabled = false;
    }

    void UpdateHighlight()
    {
        if (highlighter == null)
        {
            return;
        }

        if (hlCounter > 0)
        {
            hlCounter -= Time.deltaTime;
        }
        else
        {
            if (highlighter.IsConstantly && autoOff)
            {
                HighlightConstantOff();
            }
        }
    }

    void HighlightDirty()
    {
        if (highlighter != null)
        {
            highlighter.ReinitMaterials();
        }
    }

    void HighlightDie()
    {
        if (highlighter != null)
        {
            HighlightConstantOff();
            highlighter.Die();
        }
    }

    void HighlightEnable(bool enable)
    {
        if (highlighter != null)
        {
            highlighter.enabled = enable;
        }
    }
    #endregion


    void OnEnable()
    {
        mTransform = transform;
        HighlightEnable(false);
    }

    void OnDisable()
    {
        HighlightEnable(false);
    }

    public void CopyAnimator(DummyPlayer other)
    {
        if (other == null)
        {
            return;
        }

        if (animator == null)
        {
            return;
        }

        Skill = /*other.Skill*/-1;
        Ride = other.Ride;
        Dead = other.Dead;
        Dizz = other.Dizz;
        Speed = other.Speed;
        Hit = other.Hit;
        Run = other.Run;
    }

    public void CopyEffectControl(DummyPlayer other)
    {
        if (other == null)
        {
            return;
        }

        effectControl = other.GetEffectControl;
        if (effectControl != null)
        {
            effectControl.Retrigger();
        }
    }

    public void CopyDummy(DummyPlayer other)
    {
        CopyAnimator(other);
        CopyEffectControl(other);
    }

    public Animator GetAnimator()
    {
        return animator;
    }

    public virtual bool Run
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_RUN);
        }
        set
        {
//             if (PlayerObj && PlayerObj.RoleType == (int)Enum_ObjType.OBT_PLAYER)
//                 UniverseX.Logger.Debug("{0},{1}", value, PlayerObj);

            animator.SetBool(GameDefines.HASH_RUN, value);
            //因为目前寻路和表现没关系，跑的时候强制把表现对上，
            //TODO: 改为状态机，对外接口单一，代码表现一致.
            //同帧 false true false....只要中间有个true，最终状态又是false, //还是不要直接设置了, 省的隔几天就查一次
//             if (value && PlayerObj != null && !RideManager.IsRiding(PlayerObj))
//             {
//                 ForceAnimation(GameDefines.HASH_RUN, 0f);
//             }
        }
    }
    public bool Ride
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_RIDE);
        }
        set
        {
            animator.SetBool(GameDefines.HASH_RIDE, value);
        }
    }
    public bool Dead
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_DEAD);
        }
        set
        {
            if (value)
            {
                ResetAnimator();
                if (PlayerObj != null)
                {
                    PlayerObj.BuffPool.RemoveAll();
                }
            }

            animator.SetBool(GameDefines.HASH_DEAD, value);
        }
    }
    public bool Dizz
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_DIZZ);
        }
        set
        {
            animator.SetBool(GameDefines.HASH_DIZZ, value);
        }
    }

    public bool Stone
    {
        set
        {
            if (effectControl != null)
            {
                if (value)
                {
                    Speed = 0f;
                    ShowBase.Create(409, this);
                }
                else
                {
                    Speed = 1f;
                    effectControl.RemoveByShowId(409);
                }
            }
        }
    }

    public float Speed
    {
        get
        {
            return animator.speed;
        }
        set
        {
            animator.speed = value;
        }
    }

    public bool Hit
    {
        set
        {
            animator.SetBool(GameDefines.HASH_HIT, value);
        }
        get
        {
            return animator.GetBool(GameDefines.HASH_HIT);
        }
    }
    public bool Show
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_SHOW);
        }
        set
        {
            animator.SetBool(GameDefines.HASH_SHOW, value);
        }
    }

    public bool Relax
    {
        set
        {
            animator.SetBool(GameDefines.HASH_RELAX, value);
        }
    }

    public bool music
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_MUSIC);
        }
        set
        {
            animator.SetBool(GameDefines.HASH_MUSIC, value);
        }
    }

    public bool Fight
    {
        get
        {
            return animator.GetBool(GameDefines.HASH_FIGHT);
        }
        set
        {
            animator.SetBool(GameDefines.HASH_FIGHT, value);
        }
    }
    
    public int Skill    // 普通攻击10；技能20，21，30；XP技40。
    {
        get
        {
            switch (currentState)
            {
                case AnimatorState.Skill01:
                    return 10;
                case AnimatorState.Skill02:
                    return 20;
                case AnimatorState.Skill03:
                    return 21;
                case AnimatorState.Skill04:
                    return 30;
                case AnimatorState.Skill05:
                    return 40;
                default:
                    return -1;
            }

        }
        set
        {
            if (PlayerObj != null)
            {
                switch (value)
                {
                    case -1:
                        ForceStopSkill();
                        break;
                    case 10:
                    case 20:
                    case 21:
                    case 30:
                    case 40:
                    case 50://预留
                        PlayerObj.OnStatus(GameDefines.ROLE_STATUS_POS_SKILL);
                        animator.SetInteger(GameDefines.HASH_SKILL, value);
                        SendEvent(PlayerObj, BroadCastControl.HandleEventType.AE_UseSkill);
                        break;
                    default:
                        break;
                }
            }
            
        }
    }

    //登陆相关
    public bool Come
    {
        set
        {
            animator.SetBool("come", value);
        }
    }

    public bool Go
    {
        set
        {
            animator.SetBool("go", value);
        }
    }

    public bool CanBreak
    {
        set;
        get;
    }

    public void ResetAnimator()
    {
        Run = false;
        Dizz = false;
        Hit = false;
        Skill = -1;
        Fight = false;
    }

    void AnimStart()
    {
        Hit = false;
        Show = false;
        Relax = false;
        //music = false;
        CanBreak = false;

        SendEvent(PlayerObj, BroadCastControl.HandleEventType.AE_AnimStart);
    }

    void _EndSkill()
    {
        Skill = -1;
        CanBreak = false;
    }

	//废弃了
    void EndSkill(int skill)
    {
  //      _EndSkill(); 
    }

    void CannotBreakSkill()
    {
        CanBreak = false;
    }

    void CanBreakSkill()
    {
        CanBreak = true;

        SendEvent(PlayerObj, BroadCastControl.HandleEventType.AE_CanBreakSkill);
    }

    void SendEvent(BroadCastControl bc, BroadCastControl.HandleEventType e)
    {
        if (bc == null)
        {
            return;
        }

        bc.HandleEvent(e);
    }

    //获取当前正在播放的动画的剩余时间
    public virtual float GetCurrentAnimationClipRemainTime()
    {
        AnimatorStateInfo stateInfo = GetAnimator().GetCurrentAnimatorStateInfo(0);

        return stateInfo.length * (Mathf.CeilToInt(stateInfo.normalizedTime) - stateInfo.normalizedTime);
    }


    #endregion

    #region 装备
    #endregion


    #region 特效
    //Effect & Equipment
    private EffectControl effectControl;
    public EffectControl GetEffectControl { get { return effectControl; } }

    //绑定的自身特效
    System.Collections.Generic.List<GameObject> _BindSelfEffect = new System.Collections.Generic.List<GameObject>();

    //挂载在自身身上的Bind特效注册在本motion里面
    public virtual void AddBindSelfEffect(GameObject EffObj)
    {
        if (Skill > -1)
            _BindSelfEffect.Add(EffObj);
    }
    //把所有绑定自身的特效变成全局的
    public virtual void DetachBindSelfEffect()
    {
        if (Skill > -1)
        {
            for (int x = 0; x < _BindSelfEffect.Count; ++x)
            {
                GameObject Obj = _BindSelfEffect[x];
                if (null == Obj)
                    continue;
                //Obj.transform.parent = null;
                GameObject.Destroy(Obj);
            }
        }
    }
    #endregion

		
	//Upgrade Effect
	public GameObject upgradeEffect = null;

    //完成任务特效
    public GameObject missionDoneEffect = null;

	//脚下挂点
	protected GameObject underfooting = null;
    
	private GameDefines.AiStatus m_eAiStatus = GameDefines.AiStatus.AS_IDLE;

    
    //需要暂时隐藏自身阴影
    public GameObject ShadowEffectObj
    {
        get
        {
            return _ShadowEffectObj;
        }
    }
    GameObject _ShadowEffectObj = null;

    //脚下光圈点
    private Transform footEffectPoint = null;
    
    //modified by nsh 找到含有"_param"参数的shader的材质并使用
    private Material _highlightMat;
    private bool bInit = false;
    private Texture _DefaultMainTexture = null;
    public Texture DefaultMainTexture
    {
        get { return _DefaultMainTexture; }
        set { _DefaultMainTexture = value; }
    }

    public Material HightLightMat
    {
        get
        {
            if (!bInit)
            {
                bInit = true;
                bool bFind = false;
                Material tmpMat = null;
                SkinnedMeshRenderer[] renderers = GetComponentsInChildren<SkinnedMeshRenderer>();
                
                for (int i = 0, iMax = renderers.Length; i < iMax; i++)
                {
                    for (int j = 0, jMax = renderers[i].sharedMaterials.Length; j < jMax; j++)
                    {
                        tmpMat = renderers[i].sharedMaterials[j];

                        if (tmpMat != null && tmpMat.HasProperty("_Param"))//很慢
                        {
                            _highlightMat = renderers[i].materials[j];
                            _DefaultMainTexture = _highlightMat.mainTexture;
                            bFind = true;
                            break;
                        }
                    }

                    if (bFind)
                    {
                        break;
                    }
                }
            }

            return _highlightMat;
        }
    }
	
	// Use this for initialization
    public void Awake()
    {
        //初始化组件
        InitializeComponent();
        if (null == footEffectPoint)
        {
            footEffectPoint = Utility.FindBone(transform, GameDefines.BoneNameDef[1]);
        }
        //GameTimer.GetMe().AddTimer(_BuffPool.Tick, 0.1f);

    }

	void Start () 
	{
        //InitializeComponent();
		InitializeModel();
        GetEffectControl.SwitchEffectOnFoot(false);
        relaxCD = Random.Range(20f, 60f);
    }

	// Update is called once per frame
	public void Update () 
	{
        try
        {
            UpdateHighlight();
            //消除受击闪光
            ReduceHitHighLight();

            //休闲动作(新手引导场景就不播放休闲动作了)
            if (!NewPlayerGuideControl.IsInPlayerGuide)
            {
                TryPlayRelax();
            }

            if (effectControl != null)
            {
                effectControl.Update();
            }
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Fatal);
        }
	}

    float relaxCD = 15f;
    float relaxCounter = 0f;
    public void TryPlayRelax()
    {
        if (animator == null || PlayerObj == null)
        {
            return;
        }

        relaxCounter += Time.deltaTime;
        if (relaxCounter >= relaxCD)
        {
            if (!PlayerObj.IsOnStatus(GameDefines.ROLE_STATUS_POS_FIGHT) 
                && 
                animator.GetCurrentAnimatorStateInfo(0).IsName("idle"))
            {
                Relax = true;
            }

            relaxCounter = 0f;
        }
    }

    protected virtual void InitializeComponent()
	{
		//Init NavMeshAgent
//         if (agent == null)
//         {
//             agent = new GridNavPath.NavPathAgent();
//             agent.InitAgent(this.transform.parent.gameObject);
//         }

		// Animator
		animator = GetComponentInChildren<Animator>();
        if (animator == null)
        {
        }
		// EffectControl
		effectControl = new EffectControl(transform);

        gameObject.AddComponentEx<AnimatorStateMachine>();
	}
	
	protected virtual void InitializeModel()
	{
		
		// Init Effect
		//effectControl.InitEffectOnWeapon (DataManager.Instance.PlayerDic[this].CareerId);
		//effectControl.InitModelEffect();

        //使用池之后就别这么用了
		//脚下挂点
        //underfooting = (GameObject)Instantiate(Resources.Load("EffectPrefab/E_Blame _jiaoxiaguanghuan01"));
        //underfooting = BundleResource.GetMe().GetResourceInstance(1256);		
        //underfooting.transform.parent = transform.FindChild(@"bone_Root/root");
        //underfooting.transform.localPosition = new Vector3(0, 0.1f, 0);
		//underfooting.transform.Rotate(new Vector3(90f, 0, 0));
        //underfooting.SetActive(false);
	}

    //客户端表现的SKill唯一接口
    public virtual bool UseSkill(int skillBaseID, BroadCastControl targetObj = null)
    {
        try
        {
            SkillBase_Tbl SkillTab = com.jdxk.Configs.ConfigPool.Instance.GetDataByKey<SkillBase_Tbl>(skillBaseID);
            if (null == SkillTab)
            {
                return false;
            }

            this.TargetObj = targetObj;
            SkillID = skillBaseID;
            Skill = SkillTab.aniID;
            if (null != targetObj)
            {
                Utility.LookAtTargetImmediately(PlayerObj, targetObj);
            }

            //释放技能飘字
            if (!string.IsNullOrEmpty(SkillTab.fontname))
            {
                HUDTextManager.Instance.SetText(HUDTextManager.TextType.SKILL, SkillTab.fontname, PlayerObj);
            }

            return true;
        }
        catch (UnityException uex)
        {
            LogManager.Log(uex.ToString(), LogType.Fatal);
        }
            return false;
    }

    public virtual void Clear()
    {
        SetTarget(false, false);//清除目标时，不考虑TV动画的影响，防止重复创建GameManager
        if (effectControl != null)
        {
            effectControl.Clear();
        }
    }

	//设该怪物为攻击的焦点
    public virtual void SetTarget(bool isTartget, bool bAffectBySequence = true)
	{
        if (bAffectBySequence)
        {
            if (null != SequenceManager.Instance && SequenceManager.Instance.IsPlaying())
            {
                return;
            }
        }

        //if(null !=underfooting)
        // underfooting.SetActive(isTartget);
        if (isTartget)
        {
            if (null == underfooting || PersonControl.Instance.pkMode != this.PKMode || TargetCampId != PlayerObj.campId)
            {
                //1、没有脚下光圈点  2、我更换PK模式 3、目标更换PK模式 
                this.PKMode = PersonControl.Instance.pkMode;
                this.TargetCampId = PlayerObj.campId;
                int sign = -1;
                //可攻击目标 ---红色 1 不可攻击---蓝色 2  采集物 ---不显示 0
                if (PlayerObj.RoleType == (int)Enum_ObjType.OBT_PLAYER)
                {
                    if (AIControl.CanPlayerBeHit(PlayerObj))
                    {
                        //可攻击
                        sign = 1;
                    }
                    else
                    {
                        // 不可攻击 
                        sign = 2;
                    }
                }
                else if (PlayerObj.RoleType == (int)Enum_ObjType.OBT_NPC && PlayerObj is NpcFriend)
                {
                    NpcFriend npcF = (NpcFriend)PlayerObj;
                    //NPC
                    if (npcF.GetNpcType() == (int)NpcType.Collection ||
                        npcF.GetNpcType() == (int)NpcType.BuffDrug ||
                        npcF.GetNpcType() == (int)NpcType.Trigger)
                    {
                        //采集物
                        sign = 0;
                    }
                    else if (npcF.GetNpcType() == (int)NpcType.Normal)
                    {
                        //正常NPC
                        sign = 2;
                    }
                }
                else if (PlayerObj.RoleType == (int)Enum_ObjType.OBT_NPC && PlayerObj is NpcEnemy)
                {
                    //可攻击NPC
                    sign = 1;
                }
                else if (PlayerObj.RoleType == (int)Enum_ObjType.OBT_ROBOT)
                {
                    NpcRobot robot = (NpcRobot)PlayerObj;
                    if(robot.getRobotType() == robotType.player)
                    {
                        sign = 1;
                    }
                    else if (robot.getRobotType() == robotType.npc)
                    {
                        sign = 2;
                    }
                }
                switch (sign)
                {
                    case 0:
                        //不显示
                        break;
                    case 1:
                        //红色
                        if (null != underfooting)
                        {
                            Object.Destroy(underfooting);
                            underfooting = null;
                        }
                        underfooting = BundleResource.GetMe().GetResourceInstance(1256);
                       
                        break;
                    case 2:
                        //蓝色
                        if (null != underfooting)
                        {
                            Object.Destroy(underfooting);
                            underfooting = null;
                        }
                        underfooting = BundleResource.GetMe().GetResourceInstance(1248);
                        break;
                    default:
                        break;
                }
                if(underfooting != null)
                {
                    if (this.Ride)
                    {
                        //骑乘状态 
                        underfooting.transform.parent = PlayerObj.transform.FindChild(@"beast/bone_Root");
                    }
                    else
                    {
                        //正常状态
                        underfooting.transform.parent = footEffectPoint;
                    }
                    underfooting.transform.localRotation = Quaternion.Euler(new Vector3(0, 0, 180));
                    underfooting.transform.localPosition = new Vector3(0, 0.1f, 0);
                    Animation anima = underfooting.transform.GetChild(0).GetComponent<Animation>();
                    if (anima != null)
                    {
                        anima.enabled = true;
                    }
                }
            }
        }
        else
        {
            if (null != underfooting)
            {
                Object.Destroy(underfooting);
                underfooting = null;
            }
        }
	}
    //是否是主角
    public bool IsMainPlayer()
    {
        return PlayerObj is PersonControl;
    }
    
    //头顶飘血,只要必要数据就好
    public void BeHit(int skillflag , int DamageHP, int skillId)
    {
        //受击高光放这里吧
        HitHighLight();

        if(!(this is DummyBeast) && DamageHP < 0)
        {
            //受击动作放这把
            Hit = true;
        }     

        // 飘字放这里吧
        if (DamageHP <= 0)
        {
            GameUtility.GetServerSkillFlag2Show(skillflag, out textType);
            HUDTextManager.Instance.SetText(textType, DamageHP, PlayerObj);
        }

        // 受击特效放这里吧
        SkillBase_Tbl tbl = ConfigPool.Instance.GetDataByKey<SkillBase_Tbl>(skillId);
        if (null != tbl)
        {
            for (int i = 0; i < tbl.effect20.Length; ++i)
            {
                if (tbl.effect20[i] > 0)
                {
                    ShowBase.Create(tbl.effect20[i], this);
                }
            }
        }
    }

	public GameDefines.AiStatus getAiStatus() { return m_eAiStatus; }
	public void setAiStatus(GameDefines.AiStatus eAiStatus) { m_eAiStatus = eAiStatus; }

	public virtual bool canTouch()
	{
		return true;
	}

    //脚下阴影
    public virtual void SetShadowEffect(GameObject Obj)
    {
        _ShadowEffectObj = Obj;
    }
    public virtual void ShowShadowEffect(bool IsShow)
    {
        if (null == _ShadowEffectObj)
            return;
        _ShadowEffectObj.SetActive(IsShow);
    }

    //帮战中复活
    public void ReliveInGang(int seconds)
    {
		GangCtrl.Instance.reviveTime = seconds;
        StartCoroutine(ReliveAfterSeconds(seconds));
    }

    private IEnumerator ReliveAfterSeconds(int seconds)
    {
        yield return new WaitForSeconds(seconds);

        if (CopySceneManager.Instance.IsGangTeamCopyScene())
        {
            SceneManager.Instance.SendResurgenceMsg(SceneManager.ReliveType.PointRelive);
        }
    }

	public bool canReceiveImapct(int buffId){
		SkillBuff_Tbl buffTable = com.jdxk.Configs.ConfigPool.Instance.GetDataByKey<com.jdxk.Configs.SkillBuff_Tbl>(buffId);
		if (null == buffTable) {
			return false;
		}
		MonsterBase_Tbl monsterBase = com.jdxk.Configs.ConfigPool.Instance.GetDataByKey<MonsterBase_Tbl> (modelId);
		if (null == monsterBase) {
			return false;
		}
        MonsterAi_Tbl monsterAi = ConfigPool.Instance.GetDataByKey<MonsterAi_Tbl>(monsterBase.monsterAi);
		if (null == monsterAi) {
			return false;
		}

        bool bRet = false;
		switch ((GameDefines.CHARACTER)monsterAi.characterType) {
		case GameDefines.CHARACTER.Char_Passive:
			bRet = true;
			break;

        case GameDefines.CHARACTER.Char_Aggressive:
            bRet = true;
			break;
        case GameDefines.CHARACTER.Char_Standing:
            bRet = false;
			break;
        case GameDefines.CHARACTER.Char_Timid:
            bRet = false;
			break;
        case GameDefines.CHARACTER.Char_Pitfall:
            bRet = false;
			break;
		default:
			break;
		}
        return bRet;
	}

    public void HitHighLight()
    {
        try
        {
            if (null == HightLightMat)
                return;
            HightLightMat.SetFloat("_Param", 6f);
        }
        catch (System.Exception ex)
        {
            LogManager.Log("Got exception in HitHighLight() : " + ex.Message, LogType.Error);
        }
    }

    //因为闪光,可以有instance的材质,删掉
    void OnDestroy()
    {
        if (HightLightMat != null)
        {
            Destroy(HightLightMat);
        }
    }

    protected void ReduceHitHighLight()
    {
        try
        {
            if (null == HightLightMat)
                return;

//             if (!HightLightMat.HasProperty("_Param")) //
//             {
//                 return;
//             }
            float CurParam = HightLightMat.GetFloat("_Param");
            if (CurParam > 1)
            {
                CurParam -= Time.deltaTime * 30f; 
                if (CurParam < 1.9f)
                    CurParam = 1;
				HightLightMat.SetFloat("_Param" , CurParam);
            }
        }
        catch (System.Exception ex)
        {
            LogManager.Log("Got exception in ReduceHitHighLight() : " + ex.Message, LogType.Error);
        }
    }

    public void SetMaterialEffect(int showId)
    {
        if (effectControl != null)
        {
            effectControl.SetMaterialEffect(showId);
        }
    }

    virtual protected void OnSpawned()
    {
        m_eAiStatus = GameDefines.AiStatus.AS_IDLE;
        Dead = false;
    }

    public void SetMaterialTexture(string mat, bool isAdd = true)
    {
        if (_highlightMat == null)
        {
            return;
        }

        if (string.IsNullOrEmpty(mat))
        {
            _highlightMat.mainTexture = _DefaultMainTexture;
        }
        else
        {
            if (isAdd)
            {
                Texture tex = Resources.Load<Texture>(mat);
                if (tex != null)
	            {
                    _highlightMat.mainTexture = tex;
	            }
            }
            else
            {
                if (_highlightMat.mainTexture.name == mat)
                {
                    _highlightMat.mainTexture = _DefaultMainTexture;
                }
            }
        }
        
    }

    public void SetMaterialMatrixColor(Matrix4x4 mat)
    {
        if (_highlightMat != null)
        {
            _highlightMat.SetMatrix("_MatrixColor", mat);
        }

    }

    Matrix4x4 IceColor = Matrix4x4.identity;

    public void SetMatStatus(int state)
    {
        switch (state)
        {
            case 0:
                _highlightMat.SetMatrix("_MatrixColor", Matrix4x4.identity);
                _highlightMat.mainTexture = _DefaultMainTexture;
                break;
            case 1:
                IceColor.m00 = 0.18f;
                IceColor.m01 = 0.18f;
                IceColor.m02 = 0.5f;
                IceColor.m03 = 0f;
                IceColor.m10 = 0.18f;
                IceColor.m11 = 0.18f;
                IceColor.m12 = 0.5f;
                IceColor.m13 = 0f;
                IceColor.m20 = 0.18f;
                IceColor.m21 = 0.18f;
                IceColor.m22 = 0.5f;
                IceColor.m23 = 0f;
                _highlightMat.SetMatrix("_MatrixColor", IceColor);

                break;
            case 2:
                IceColor.m00 = 0.14f;
                IceColor.m01 = 0.3f;
                IceColor.m02 = 0.06f;
                IceColor.m03 = 0f;
                IceColor.m10 = 0.14f;
                IceColor.m11 = 0.3f;
                IceColor.m12 = 0.06f;
                IceColor.m13 = 0f;
                IceColor.m20 = 0.14f;
                IceColor.m21 = 0.3f;
                IceColor.m22 = 0.06f;
                IceColor.m23 = 0f;
                _highlightMat.SetMatrix("_MatrixColor", IceColor);

                break;
            case 3:
                _highlightMat.SetMatrix("_MatrixColor", Matrix4x4.identity);
                Texture tex = Resources.Load<Texture>("Textures/shatu");
                _highlightMat.mainTexture = tex;
                break;
            default:
                break;
        }
    }

    #region 新技能

    enum AnimatorState
    {
        Idle,
        Skill01,
        Skill02,
        Skill03,
        Skill04,
        Skill05,
    }

    bool forceInTransitionFlag = false;
    AnimatorState currentState = AnimatorState.Idle;
    bool bSkillFalgReset = false;
    const float skillTransitionDuration = 0.15f;

    public bool IsInSkillTransition()
    {
        bool ret = Skill > 0 && (animator.IsInTransition(0) || forceInTransitionFlag);
        if (ret)
        {
      //      LogSkillInfo("IsInSkillTransition");
        }
        return ret;
    }

    void LogSkillInfo(object name)
    {
        if (PlayerObj != null && PlayerObj.RoleType == (int)Enum_ObjType.OBT_PLAYER)
        {
            AnimationInfo[] clipState = animator.GetCurrentAnimationClipState(0);
            string clips = "";
            foreach (var item in clipState)
            {
                clips += item.clip;
                clips += ",";
            }

            AnimatorStateInfo info = animator.GetCurrentAnimatorStateInfo(0);

            UniverseX.Logger.Debug("{0},{1}, state:{2}, skillParam:{3}, skillstate:{4}, currentClips:{5}, normalizedTime:{6}, IsInTransition:{7}, forceInTransitionFlag:{8}",
                PlayerObj.charName, name.ToString(), currentState, animator.GetInteger(GameDefines.HASH_SKILL), PlayerObj.IsOnStatus(GameDefines.ROLE_STATUS_POS_SKILL),
                clips, info.normalizedTime, animator.IsInTransition(0), forceInTransitionFlag
                );
        }
    }

    //
    public void ForceAnimation(int stateNameHash, float duration = skillTransitionDuration)
    {
        if (PlayerObj != null && animator != null)
        {
            animator.CrossFade(stateNameHash, duration);
        }
    }

    public void ForceStopSkill(float duration = skillTransitionDuration)
    {
        if (PlayerObj != null && animator != null && Skill > 0 && !forceInTransitionFlag)
        {
            animator.SetInteger(GameDefines.HASH_SKILL, -1);
            bool change2Fight = PlayerObj.RoleType == (int)Enum_ObjType.OBT_PLAYER && Fight 
                && !PlayerObj.IsOnStatus(GameDefines.ROLE_STATUS_POS_SOUL)
                && ( (PlayerObj.careerId == (int)GameDefines.ProfessionType.PoJun) || (PlayerObj.careerId == (int)GameDefines.ProfessionType.QingMing) );
            //职业没加全呢

            if (change2Fight)
            {
                animator.CrossFade(GameDefines.HASH_FIGHT, duration);
            }
            else
            {
                animator.CrossFade(GameDefines.HASH_IDLE, duration);
            }

            forceInTransitionFlag = true;
        }
    }

    void SkillParamsReset()
    {
        if (!bSkillFalgReset)
        {
            bSkillFalgReset = true;
            animator.SetInteger(GameDefines.HASH_SKILL, -1);
      //      LogSkillInfo("SkillParamsReset");
        }
    }

    void OnEnterSkillState()
    {
        bSkillFalgReset = false;
        forceInTransitionFlag = false;

        if (PlayerObj != null)
        {
            PlayerObj.OnStatus(GameDefines.ROLE_STATUS_POS_SKILL);
        }

   //     LogSkillInfo("OnEnterSkillState");
    }

    void OnExitSkillState()
    {
        if (PlayerObj != null)
        {
            PlayerObj.EndStatus(GameDefines.ROLE_STATUS_POS_SKILL);

            if (PlayerObj.trail != null)
            {
                PlayerObj.trail.EndTrail();
            }

            SendEvent(PlayerObj, BroadCastControl.HandleEventType.AE_EndSkill);
        }

        forceInTransitionFlag = false;
 //     LogSkillInfo("OnExitSkillState");
    }

    #region 状态部分禁止添加逻辑代码
    /// <summary>
    /// Skill01
    /// </summary>
    [StateEnterMethod("skill.skill01")]
    public void Skill01Enter()
    {
        currentState = AnimatorState.Skill01;
        OnEnterSkillState();
    }

    [StateUpdateMethod("skill.skill01")]
    public void Skill01Update()
    {
        SkillParamsReset();
    }

    [StateExitMethod("skill.skill01")]
    public void Skill01Exit()
    {
        OnExitSkillState();
        currentState = AnimatorState.Idle;
    }

    /// <summary>
    /// Skill02
    /// </summary>
    [StateEnterMethod("skill.skill02")]
    public void Skill02Enter()
    {
        currentState = AnimatorState.Skill02;
        OnEnterSkillState();
    }

    [StateUpdateMethod("skill.skill02")]
    public void Skill02Update()
    {
        SkillParamsReset();
    }

    [StateExitMethod("skill.skill02")]
    public void Skill02Exit()
    {
        OnExitSkillState();
        currentState = AnimatorState.Idle;
    }

    /// <summary>
    /// Skill03
    /// </summary>
    [StateEnterMethod("skill.skill03")]
    public void Skill03Enter()
    {
        currentState = AnimatorState.Skill03;
        OnEnterSkillState();
    }

    [StateUpdateMethod("skill.skill03")]
    public void Skill03Update()
    {
        SkillParamsReset();
    }

    [StateExitMethod("skill.skill03")]
    public void Skill03Exit()
    {
        OnExitSkillState();
        currentState = AnimatorState.Idle;
    }

    /// <summary>
    /// Skill04
    /// </summary>
    [StateEnterMethod("skill.skill04")]
    public void Skill04Enter()
    {
        currentState = AnimatorState.Skill04;
        OnEnterSkillState();
    }

    [StateUpdateMethod("skill.skill04")]
    public void Skill04Update()
    {
        SkillParamsReset();
    }

    [StateExitMethod("skill.skill04")]
    public void Skill04Exit()
    {
        OnExitSkillState();
        currentState = AnimatorState.Idle;
    }

    /// <summary>
    /// Skill05
    /// </summary>
    [StateEnterMethod("skill.skill05")]
    public void Skill05Enter()
    {
        currentState = AnimatorState.Skill05;
        OnEnterSkillState();
    }

    [StateUpdateMethod("skill.skill05")]
    public void Skill05Update()
    {
        SkillParamsReset();
    }

    [StateExitMethod("skill.skill05")]
    public void Skill05Exit()
    {
        OnExitSkillState();
        currentState = AnimatorState.Idle;
    }
    #endregion

    #endregion
}
